import { serve } from "std/server";
import { createClient } from "@supabase/supabase-js";
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const sb = createClient(SUPABASE_URL, SERVICE_KEY);
serve(async (req) => {
  try {
    const url = new URL(req.url);
    const pathname = url.pathname;
    if (req.method === 'GET' && pathname.endsWith('/signed-url')) {
      const p = url.searchParams.get('path');
      const { data, error } = await sb.storage.from('private-ids').createSignedUrl(p, 120);
      if (error) return new Response(JSON.stringify({ error: error.message }), { status: 500 });
      return new Response(JSON.stringify({ signedUrl: data.signedUrl }), { status: 200 });
    }
    if (req.method === 'GET' && pathname.endsWith('/verifications/pending')) {
      const { data: rows } = await sb.from('seller_verifications').select('*').eq('status', 'pending').limit(200);
      const out = await Promise.all(rows.map(async (r:any)=> {
        const mk = async (p:string|null)=> { if(!p) return null; const { data } = await sb.storage.from('private-ids').createSignedUrl(p,120); return data?.signedUrl || null; };
        return { id: r.id, user_id: r.user_id, id_type: r.id_type, submitted_at: r.submitted_at, id_front_signed: await mk(r.id_front_path), id_back_signed: await mk(r.id_back_path), selfie_signed: await mk(r.selfie_path) };
      }));
      return new Response(JSON.stringify(out), { status: 200 });
    }
    return new Response(JSON.stringify({ error: 'not found' }), { status: 404 });
  } catch (err:any) { return new Response(JSON.stringify({ error: String(err) }), { status: 500 }); }
});
