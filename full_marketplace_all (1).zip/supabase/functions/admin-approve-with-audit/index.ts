import { serve } from 'std/server';
import { createClient } from '@supabase/supabase-js';
const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
const SERVICE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const ADMIN_FN_SECRET = Deno.env.get('ADMIN_FN_SECRET');
const sb = createClient(SUPABASE_URL, SERVICE_KEY);
serve(async (req) => {
  try {
    if (req.method !== 'POST') return new Response(JSON.stringify({ error: 'Method not allowed' }), { status: 405 });
    const body = await req.json();
    const { verificationId, action, adminId, adminNotes, secret } = body;
    if (ADMIN_FN_SECRET && secret !== ADMIN_FN_SECRET) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401 });
    if (!verificationId || !['approve','reject'].includes(action) || !adminId) return new Response(JSON.stringify({ error: 'Missing fields' }), { status: 400 });
    const v = await sb.from('seller_verifications').select('*').eq('id', verificationId).single();
    const userId = v.data.user_id;
    if (action === 'approve') {
      await sb.from('seller_verifications').update({ status: 'approved', admin_notes: adminNotes || null, reviewed_at: new Date().toISOString() }).eq('id', verificationId);
      await sb.from('profiles').update({ verification_status: 'approved' }).eq('id', userId);
    } else {
      await sb.from('seller_verifications').update({ status: 'rejected', admin_notes: adminNotes || null, reviewed_at: new Date().toISOString() }).eq('id', verificationId);
      await sb.from('profiles').update({ verification_status: 'rejected' }).eq('id', userId);
    }
    await sb.from('admin_audit').insert([{ admin_id: adminId, action, target_type: 'verification', target_id: verificationId, notes: adminNotes || null }]);
    return new Response(JSON.stringify({ ok: true }), { status: 200 });
  } catch (err:any) { return new Response(JSON.stringify({ error: String(err) }), { status: 500 }); }
});
