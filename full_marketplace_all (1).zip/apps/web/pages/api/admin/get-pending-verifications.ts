import type { NextApiRequest, NextApiResponse } from 'next';
const ADMIN_HELPERS_EDGE_FN_URL = process.env.ADMIN_HELPERS_EDGE_FN_URL;
const ADMIN_FN_SECRET = process.env.ADMIN_FN_SECRET;
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });
  const edgeRes = await fetch(`${ADMIN_HELPERS_EDGE_FN_URL}/verifications/pending`, { method: 'GET', headers: { 'x-admin-fn-secret': ADMIN_FN_SECRET || '' } });
  const json = await edgeRes.json();
  return res.status(edgeRes.status).json(json);
}
