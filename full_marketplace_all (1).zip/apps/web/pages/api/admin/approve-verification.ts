import type { NextApiRequest, NextApiResponse } from 'next';
const ADMIN_APPROVE_EDGE_FN_URL = process.env.ADMIN_APPROVE_EDGE_FN_URL;
const ADMIN_FN_SECRET = process.env.ADMIN_FN_SECRET;
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  const body = req.body;
  const edgeRes = await fetch(ADMIN_APPROVE_EDGE_FN_URL, { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-admin-fn-secret': ADMIN_FN_SECRET || '' }, body: JSON.stringify({ ...body, secret: ADMIN_FN_SECRET }) });
  const json = await edgeRes.json();
  return res.status(edgeRes.status).json(json);
}
