# Campus Marketplace - Full Monorepo

This archive contains the full scaffold for the Campus Marketplace project (web, admin, mobile, api, supabase, deployment scripts).

See folders:
- apps/web
- apps/admin
- apps/mobile
- api
- supabase
- infra (CI / deploy scripts)

Follow READMEs in each folder for run instructions.
