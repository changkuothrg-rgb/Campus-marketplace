#!/usr/bin/env bash
echo "Deploying supabase functions..."
supabase functions deploy admin-helpers
supabase functions deploy admin-approve-with-audit
